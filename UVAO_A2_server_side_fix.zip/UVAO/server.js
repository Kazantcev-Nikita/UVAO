const storage = require('./storage/storage.js');
const utility = require('./storage/utility.js');

const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let ESP = null;


const ESP_KEY = "737c1bb3962dde6b39dddc6b5b236180";

// Serve static files from the "client" directory
app.use(express.static(path.join(__dirname, 'client')));

// Middleware to handle requests to the root URL / handle client request to get page
app.get('/', (req, res) => {
    res.redirect('/client'); // Redirect to the client directory
});

app.get('/questions', (req, res) => {
    if (req.headers.key === "123") {
        res.json(storage.questions)
    } else {
        res.status(403).json("куда ты полез...")
    }
    
})

// manage WS connection

let clients = {}

wss.on('connection', (ws) => {
    console.log('Client connected');

    clients[ws] = JSON.parse(JSON.stringify(storage.SERVER_STARTER_PACK))


    ws.send('Welcome to the WebSocket server!');


    ws.on('message', (message) => {
        const stringed_message = message.toString();
        console.log("stringed:", stringed_message)

        if (stringed_message === ESP_KEY) {                 // CHECK IF ESP
            console.log('KEY otpravlen, ESP connect');
            ws.send("Кодовое слово принято!");
            ESP = ws;

            ESP.onclose = function() {
                ESP = null;
            }
            
            return;
        }
        if (stringed_message.startsWith("question")) {
            const parsed = utility.parser(stringed_message);
            const ans_id = parsed[0]
            const value = parsed[1]
            
            if (storage.CORRECTS[ans_id].correct === value) {

                clients[ws][ans_id].state = true;
                ws.send(ans_id + ' true');

                if (utility.all(clients[ws])) {
                    ws.send("PASS");
                }

                return;
            }

            if (clients[ws][ans_id].state) {
                return;
            }

            ws.send(ans_id + ' false');
            clients[ws][ans_id].state = false;

            return;
        }

        if (stringed_message !== "check") {                 // CHECK IF VALID DATA
            ws.close(1000, 'close_info: cheater');
            return;
        }
        
        if (!utility.all(clients[ws])) {
            ws.close(1000, "close_info: cheater 2.0")
        }

        if (!ESP || ESP.readyState == 2 || ESP.readyState == 3) { // if WS connection is closed or closing
            ws.send("ESP_na");
            ws.close(1000, "close_info: not available");
            return;
        }


        console.log("Test passed, sending ball");
        
        ESP.send('go');

        ws.close(1000, "close_info: all good");
    });

    ws.on("close", () => {
        clients[ws] = null;
    });

});



server.listen(8080, () => {
    console.log('WebSocket server is listening on ws://localhost:8080');
});
