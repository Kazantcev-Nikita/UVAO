const questions = {
    question1: {
        rayon: "Район Лефортово",
        id: "lefortovo",
        text: "В каком округе до 1990-х годов находился район Лефортово?",
        answers: ["Южный", "Восточный", "Центральный", "Был все время в Юго-Восточном"]
    },
    question2: {
        rayon: "Нижегородский район",
        id: "nizhegorodskiy",
        text: "Какая река находится в Нижегородском районе?",
        answers: ["Москва", "Нищенка", "Яуза", "Каменка"]
    },
    question3: {
        rayon: "Район Некрасовка",
        id: "nekrasovka",
        text: "Какова примерная площадь Некрасовки?",
        answers: ["~1100 га", "~500 га", "~100 га", "~1600 га"]
    },
    question4: {
        rayon: "Южнопортовый район",
        id: "yuzhnoportoviy",
        text: "В честь чего назван район Южнопортовый?",
        answers: ["Назван в честь близлежащей станции метро", "Назван в честь улицы, проходящей по границе района", "Назван в честь названия ТЦ", "Назвал Мэр Москвы"]
    },
    question5: {
        rayon: "Район Текстильщики",
        id: "textilshiki",
        text: "В каком году район Текстильщики стал самостоятельным районом Москвы?",
        answers: ["1995", "1990", "2001", "1998"]
    },
    question6: {
        rayon: "Рязанский район",
        id: "razanskiy",
        text: "Каково примерное кол-во населения в Рязанском районе (в тыс.)?",
        answers: ["~100", "~200", "~20", "~300"]
    },
    question7: {
        rayon: "Район Кузьминки",
        id: "kuzminki",
        text: "Как называется один из самых больших фонтанов, находящийся в Кузьминках?",
        answers: ["Дружба народов", "Каменный цветок", "Летящий журавль", "Музыка Славы"]
    },
    question8: {
        rayon: "Район Печатники",
        id: "pechatniki",
        text: "Какая самая длинная улица в Печатниках?",
        answers: ["Шоссейная", "Полбина", "Кухмистерова", "Гурянова"]
    },
    question9: {
        rayon: "Район Выхино-Жулебино",
        id: "vihino",
        text: "Какой крупный парк входит в район Выхино-Жулебино?",
        answers: ["Кузьминки", "Кусковский", "Терлецкий", "850-летия Москвы"]
    },
    question10: {
        rayon: "Район Люблино",
        id: "lublino",
        text: "На какой линии находится одноименная станция метро?",
        answers: ["Таганско-Краснопресненской", "Некрасовской", "Люблинско-Дмитровской", "Замоскворецкой"]
    },
    question11: {
        rayon: "Район Марьино",
        id: "marino",
        text: "До какого года Марьино являлось самым населенным районом Москвы?",
        answers: ["До 2000", "До 2017", "Является таким до сих пор", "До 2020"]
    },
    question12: {
        rayon: "Район Капотня",
        id: "kapotnya",
        text: "Как называется главное учреждение культуры в районе Капотня?",
        answers: ['парк "Яблоневый сад"', 'Дворец Культуры "Капотня"', 'стадион "Cмена"', "Парк 85-летия МНПЗ"]
    }
}

const CORRECTS = {
    question1: {
        correct: "Центральный"
    },
    question2: {
        correct: "Нищенка"
    },
    question3: {
        correct: "~1100 га"
    },
    question4: {
        correct: "Назван в честь улицы, проходящей по границе района"
    },
    question5: {
        correct: "1995"
    },
    question6: {
        correct: "~100"
    },
    question7: {
        correct: "Музыка Славы"
    },
    question8: {
        correct: "Шоссейная"
    },
    question9: {
        correct: "Кузьминки"
    },
    question10: {
        correct: "Люблинско-Дмитровской"
    },
    question11: {
        correct: "Является таким до сих пор"
    },
    question12: {
        correct: 'Дворец Культуры "Капотня"'
    }
}

const SERVER_STARTER_PACK = {
    question1: {
        state: null,
    },
    question2: {
        state: null
    },
    question3: {
        state: null
    },
    question4: {
        state: null
    },
    question5: {
        state: null
    },
    question6: {
        state: null
    },
    question7: {
        state: null
    },
    question8: {
        state: null
    },
    question9: {
        state: null
    },
    question10: {
        state: null
    },
    question11: {
        state: null
    },
    question12: {
        state: null
    }
}

const data = {questions, SERVER_STARTER_PACK, CORRECTS}

module.exports = data