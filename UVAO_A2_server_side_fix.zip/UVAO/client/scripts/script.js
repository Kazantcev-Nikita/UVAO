let socket;

let questions;

let reconnectInterval = 1000;
let reconnectTimes = 0;
const maxReconnectTimes = 8;
const maxReconnectInterval = 16000;

function reconnect() {
    if (reconnectTimes >= maxReconnectTimes) {
        console.warn("Cannot restore WebSocket connection, service unavailable!")
        showPopup("error", "Сервер недоступен.")
        return;
    }
    console.log(`Attempting to reconnect in ${reconnectInterval / 1000} seconds...`);
    
    reconnectTimes += 1;

    setTimeout(() => {
        connect(); // Attempt to reconnect
        reconnectInterval = Math.min(reconnectInterval * 2, maxReconnectInterval); // Exponential backoff
    }, reconnectInterval);
}

function connect() {
    socket = new WebSocket("ws://" + location.host);

    socket.onopen = function(event) {
        reconnectInterval = 1000;
        reconnectTimes = 0;

        // setup
        
        fetch("http://" + location.host + "/questions", {method: "GET", headers: {"key": "123"}})
            .then((response) => {
                if (!response.ok) {
                    console.warn("Something wrong with fetch GET response!");
                    return;
                }
                return response.json();
            }).then(data => {questions = data})
        
        
    };

    socket.onclose = function(event) {
        if (event.wasClean) {
            console.log('Closing WS connection with exit code:', event.code, event.reason)
        } else {
            console.log('WebSocket connection lost!')
            reconnect()
        }
    };

    socket.onmessage = function(message) {
        if (message.data === "ESP_na") {
            showPopup('error', "Нет связи со стендом!");
        }
        console.log('Recieved message:', message.data);

        if (message.data.split(" ")[0].startsWith("question")) {
            const parsed = message.data.split(" ")
            const id = parsed[0]
            const value = JSON.parse(parsed[1])

            const imageElement = document.getElementById(questions[id].id);

            if (value) {
                imageElement.setAttribute("fill", "#00ff00");
                imageElement.setAttribute("class", "solved");
                imageElement.removeAttribute("onclick");
            } else {
                imageElement.setAttribute("fill", "#ff0000");
            }
        }

        if (message.data === "PASS") {
            setTimeout(() => {
                document.getElementById("finalText").innerText = 'Вы прошли квест, положите шарик на место и нажмите "Отправить"';
                document.getElementById("finalPopUp").style.display = "flex";
            }, 250);
        }
    };
}


function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        // Generate a random index from 0 to i
        const j = Math.floor(Math.random() * (i + 1));

        // Swap elements at indices i and j
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}



function getSocketText() {
    let text = ""

    for (let i = 0; i < Object.keys(questions).length; i++) {
        text += JSON.stringify(questions[Object.keys(questions)[i]].state)[0]
    }

    return text
}

function showPopup(questionKey, error_info) {
    const answersDiv = document.getElementById("answers");
    answersDiv.innerHTML = ""; // Clear previous answers


    if (questionKey == "error") {
        document.getElementById("question-text").innerText = error_info;
        document.getElementById("rayon").innerText = "Ошибка";
        answersDiv.innerHTML = "";

        document.getElementById("popup").style.display = "flex";

        return;
    }

    const question = questions[questionKey];
    question.answers = shuffleArray(question.answers);
    document.getElementById("question-text").innerText = question.text;
    document.getElementById("rayon").innerText = question.rayon;


    question.answers.forEach(answer => {
        const answerButton = document.createElement("button");
        answerButton.innerText = answer;

        // Add event listener to check answer
        answerButton.onclick = function() {
            checkAnswer(answer, questionKey);
        };

        answersDiv.appendChild(answerButton);
    });
    document.getElementById("popup").style.display = "flex";
}

function checkAnswer(selectedAnswer, ID) {
    socket.send(ID + "::" + selectedAnswer);
    // Optionally close the popup after selecting an answer
    closePopup('popup');
}

function sendball(){
    document.getElementById("finalPopUp").style.display = "none";

    socket.send("check");

    console.log('шарик полетел'); // ball go go go
}

function closePopup(id) {
    document.getElementById(id).style.display = "none";
}

connect()