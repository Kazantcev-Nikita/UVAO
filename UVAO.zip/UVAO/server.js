const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let ESP = null;

const KEY = "737c1bb3962dde6b39dddc6b5b236180";

// Serve static files from the "client" directory
app.use(express.static(path.join(__dirname, 'client')));

// Middleware to handle requests to the root URL / handle client request to get page
app.get('/', (req, res) => {
    res.redirect('/client'); // Redirect to the client directory
});

// manage WS connection

wss.on('connection', (ws) => {
    console.log('Client connected');

    ws.send('Welcome to the WebSocket server!');


    ws.on('message', (message) => {
        const stringed_message = message.toString();
        //console.log("stringed:", stringed_message)

        if (stringed_message === KEY) { // key
            console.log('KEY otpravlen, ESP connect');
            ws.send("Кодовое слово принято!");
            ESP = ws;

            ESP.onclose = function() {
                ESP = null;
            }
            
            return;
        }

        if (stringed_message !== "tttttttttttt") { // 12 true's
            ws.close(1000, 'close_info: cheater');
            return;
        }
        
        if (!ESP || ESP.readyState == 2 || ESP.readyState == 3) { // if WS connection is closed or closing
            ws.send("ESP_na");
            ws.close(1000, "close_info: not available");
            return;
        }

        console.log("Test passed, sending ball");
        
        ESP.send('go');

        ws.close(1000, "close_info: all good");
    });

});

server.listen(8080, () => {
    console.log('WebSocket server is listening on ws://localhost:8080');
});
