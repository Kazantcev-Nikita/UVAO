let socket;
let reconnectInterval = 1000;
let reconnectTimes = 0;
const maxReconnectTimes = 8;
const maxReconnectInterval = 16000;

function reconnect() {
    if (reconnectTimes >= maxReconnectTimes) {
        console.warn("Cannot restore WebSocket connection, service unavailable!")
        showPopup("error", "Сервер недоступен.")
        return;
    }
    console.log(`Attempting to reconnect in ${reconnectInterval / 1000} seconds...`);
    
    reconnectTimes += 1;

    setTimeout(() => {
        connect(); // Attempt to reconnect
        reconnectInterval = Math.min(reconnectInterval * 2, maxReconnectInterval); // Exponential backoff
    }, reconnectInterval);
}

function connect() {
    socket = new WebSocket("ws://" + location.host);

    socket.onopen = function(event) {
        reconnectInterval = 1000
        reconnectTimes = 0
    };

    socket.onclose = function(event) {
        if (event.wasClean) {
            console.log('Closing WS connection with exit code:', event.code, event.reason)
        } else {
            console.log('WebSocket connection lost!')
            reconnect()
        }
    };

    socket.onmessage = function(message) {
        if (message.data === "ESP_na") {
            showPopup('error', "Нет связи со стендом!")
        }
        console.log('Recieved message:', message.data)
    };
}

const questions = {
    question1: {
        rayon: "Район Лефортово",
        id: "lefortovo",
        text: "В каком округе до 1990-х годов находился район Лефортово?",
        answers: ["Южный", "Восточный", "Центральный", "Был все время в Юго-Восточном"],
        correct: "Центральный",
        state: null
    },
    question2: {
        rayon: "Нижегородский район",
        id: "nizhegorodskiy",
        text: "Какая река находится в Нижегородском районе?",
        answers: ["Москва", "Нищенка", "Яуза", "Каменка"],
        correct: "Нищенка",
        state: null
    },
    question3: {
        rayon: "Район Некрасовка",
        id: "nekrasovka",
        text: "Какова примерная площадь Некрасовки?",
        answers: ["~1100 га", "~500 га", "~100 га", "~1600 га"],
        correct: "~1100 га",
        state: null
    },
    question4: {
        rayon: "Южнопортовый район",
        id: "yuzhnoportoviy",
        text: "В честь чего назван район Южнопортовый?",
        answers: ["Назван в честь близлежащей станции метро", "Назван в честь улицы, проходящей по границе района", "Назван в честь названия ТЦ", "Назвал Мэр Москвы"],
        correct: "Назван в честь улицы, проходящей по границе района",
        state: null
    },
    question5: {
        rayon: "Район Текстильщики",
        id: "textilshiki",
        text: "В каком году район Текстильщики стал самостоятельным районом Москвы?",
        answers: ["1995", "1990", "2001", "1998"],
        correct: "1995",
        state: null
    },
    question6: {
        rayon: "Рязанский район",
        id: "razanskiy",
        text: "Каково примерное кол-во населения в Рязанском районе (в тыс.)?",
        answers: ["~100", "~200", "~20", "~300"],
        correct: "~100",
        state: null
    },
    question7: {
        rayon: "Район Кузьминки",
        id: "kuzminki",
        text: "Как называется один из самых больших фонтанов, находящийся в Кузьминках?",
        answers: ["Дружба народов", "Каменный цветок", "Летящий журавль", "Музыка Славы"],
        correct: "Музыка Славы",
        state: null
    },
    question8: {
        rayon: "Район Печатники",
        id: "pechatniki",
        text: "Какая самая длинная улица в Печатниках?",
        answers: ["Шоссейная", "Полбина", "Кухмистерова", "Гурянова"],
        correct: "Шоссейная",
        state: null
    },
    question9: {
        rayon: "Район Выхино-Жулебино",
        id: "vihino",
        text: "Какой крупный парк входит в район Выхино-Жулебино?",
        answers: ["Кузьминки", "Кусковский", "Терлецкий", "850-летия Москвы"],
        correct: "Кузьминки",
        state: null
    },
    question10: {
        rayon: "Район Люблино",
        id: "lublino",
        text: "На какой линии находится одноименная станция метро?",
        answers: ["Таганско-Краснопресненской", "Некрасовской", "Люблинско-Дмитровской", "Замоскворецкой"],
        correct: "Люблинско-Дмитровской",
        state: null
    },
    question11: {
        rayon: "Район Марьино",
        id: "marino",
        text: "До какого года Марьино являлось самым населенным районом Москвы?",
        answers: ["До 2000", "До 2017", "Является таким до сих пор", "До 2020"],
        correct: "Является таким до сих пор",
        state: null
    },
    question12: {
        rayon: "Район Капотня",
        id: "kapotnya",
        text: "Как называется главное учреждение культуры в районе Капотня?",
        answers: ['парк "Яблоневый сад"', 'Дворец Культуры "Капотня"', 'стадион "Cмена"', "Парк 85-летия МНПЗ"],
        correct: 'Дворец Культуры "Капотня"',
        state: null
    }
}


function all(){
    for (let i = 0; i < Object.keys(questions).length; i++){
        if (!questions[Object.keys(questions)[i]].state){
            return false;
        }
        
    }
    return true;
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        // Generate a random index from 0 to i
        const j = Math.floor(Math.random() * (i + 1));

        // Swap elements at indices i and j
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function getSocketText() {
    let text = ""

    for (let i = 0; i < Object.keys(questions).length; i++) {
        text += JSON.stringify(questions[Object.keys(questions)[i]].state)[0]
    }

    return text
}

function showPopup(questionKey, error_info) {
    const answersDiv = document.getElementById("answers");
    answersDiv.innerHTML = ""; // Clear previous answers


    if (questionKey == "error") {
        document.getElementById("question-text").innerText = error_info;
        document.getElementById("rayon").innerText = "Ошибка";
        answersDiv.innerHTML = "";

        document.getElementById("popup").style.display = "flex";

        return;
    }

    const question = questions[questionKey];
    question.answers = shuffleArray(question.answers);
    document.getElementById("question-text").innerText = question.text;
    document.getElementById("rayon").innerText = question.rayon;


    question.answers.forEach(answer => {
        const answerButton = document.createElement("button");
        answerButton.innerText = answer;

        // Add event listener to check answer
        answerButton.onclick = function() {
            checkAnswer(question.correct, answer, question.id, question);
        };

        answersDiv.appendChild(answerButton);
    });
    document.getElementById("popup").style.display = "flex";
}

function checkAnswer(correctAnswer, selectedAnswer, ID, question) {
    const imageElement = document.getElementById(ID); // Assuming you want to change the first image
    if (selectedAnswer === correctAnswer) {
        imageElement.setAttribute("fill", "#00ff00");
        imageElement.setAttribute("class", "solved");
        imageElement.removeAttribute("onclick");
        question.state = true;
    } else {
        imageElement.setAttribute("fill", "#ff0000");
        question.state = false;
    }

    // Optionally close the popup after selecting an answer
    closePopup('popup');

    if (all()){ //all()
        setTimeout(() => {
            document.getElementById("finalText").innerText = 'Вы прошли квест, положите шарик на место и нажмите "Отправить"';
            document.getElementById("finalPopUp").style.display = "flex";
        }, 250);
    }
}

function sendball(){
    if (all()){
        const socket_text = getSocketText()

        document.getElementById("finalPopUp").style.display = "none";
        socket.send(socket_text);

        console.log('шарик полетел'); // ball go go go
    } else {
        socket.send("close")
        document.getElementById("finalText").innerText = "Лжец";
    }
}

function closePopup(id) {
    document.getElementById(id).style.display = "none";
}

connect()